package com.bradford.mfa;

import com.bradford.mfa.model.*;
import com.bradford.mfa.service.AuthenticationService;
import com.bradford.mfa.app.factory.AuthenticationMethodProviderFactory;
import com.bradford.mfa.auth.*;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration-style tests covering the full authentication flow
 * across all authentication mechanisms (non-GUI).
 */
public class AuthenticationFlowTest {

    private User createTestUser() {
        return new User(
                "testUser",
                "password",
                "test@email.com",
                "07123456789"
        );
    }

    // ---------------- PASSWORD ----------------

    @Test
    void authenticationFlow_withCorrectPassword_shouldPassFirstFactor() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        AuthResult result = service.authenticatePassword(
                createTestUser(),
                new AuthContext("testUser", "password", "")
        );

        assertTrue(result.isSuccess());
    }

    @Test
    void authenticationFlow_withIncorrectPassword_shouldFailImmediately() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        AuthResult result = service.authenticatePassword(
                createTestUser(),
                new AuthContext("testUser", "wrongPassword", "")
        );

        assertFalse(result.isSuccess());
    }

    // ✅ Improves PasswordAuthentication mutation score
    @Test
    void authenticationFlow_withEmptyPassword_shouldFail() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        AuthResult result = service.authenticatePassword(
                createTestUser(),
                new AuthContext("testUser", "", "")
        );

        assertFalse(result.isSuccess());
    }

    @Test
    void authenticationFlow_withNullPassword_shouldFail() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        AuthResult result = service.authenticatePassword(
                createTestUser(),
                new AuthContext("testUser", null, "")
        );

        assertFalse(result.isSuccess());
    }

    // ---------------- EMAIL OTP ----------------

    @Test
    void authenticationFlow_withEmailOtpInvalidCode_shouldFail() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        assertTrue(service.authenticatePassword(
                createTestUser(),
                new AuthContext("testUser", "password", "")
        ).isSuccess());

        AuthResult mfaResult = service.verifyMfa(
                createTestUser(),
                new AuthContext("testUser", "password", "000000"),
                MfaMethodType.EMAIL_OTP
        );

        assertFalse(mfaResult.isSuccess());
    }

    // ---------------- SMS OTP ----------------

    @Test
    void authenticationFlow_withSmsOtpInvalidCode_shouldFail() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        assertTrue(service.authenticatePassword(
                createTestUser(),
                new AuthContext("testUser", "password", "")
        ).isSuccess());

        AuthResult mfaResult = service.verifyMfa(
                createTestUser(),
                new AuthContext("testUser", "password", "000000"),
                MfaMethodType.SMS_OTP
        );

        assertFalse(mfaResult.isSuccess());
    }

    // ---------------- TOTP ----------------

    @Test
    void authenticationFlow_withTotpNullCode_shouldFail() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        assertTrue(service.authenticatePassword(
                createTestUser(),
                new AuthContext("testUser", "password", "")
        ).isSuccess());

        AuthResult mfaResult = service.verifyMfa(
                createTestUser(),
                new AuthContext("testUser", "password", null),
                MfaMethodType.TOTP
        );

        assertFalse(mfaResult.isSuccess());
    }

    @Test
    void authenticationFlow_withTotpEmptyCode_shouldFail() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        assertTrue(service.authenticatePassword(
                createTestUser(),
                new AuthContext("testUser", "password", "")
        ).isSuccess());

        AuthResult mfaResult = service.verifyMfa(
                createTestUser(),
                new AuthContext("testUser", "password", ""),
                MfaMethodType.TOTP
        );

        assertFalse(mfaResult.isSuccess());
    }

    // ✅ Improves AuthenticationService defensive branch
    @Test
    void authenticationFlow_withNullMfaMethod_shouldThrowException() {
        AuthenticationService service =
                new AuthenticationService(new AuthenticationMethodProviderFactory());

        assertThrows(IllegalArgumentException.class, () -> {
            service.verifyMfa(
                    createTestUser(),
                    new AuthContext("testUser", "password", "123456"),
                    null
            );
        });
    }

    // ---------------- MODEL ----------------

    // ✅ Improves AuthResult mutation score
    @Test
    void authResult_successAndFailure_shouldDiffer() {
        AuthResult success = AuthResult.success("ok");
        AuthResult failure = AuthResult.failure("fail");

        assertTrue(success.isSuccess());
        assertFalse(failure.isSuccess());
    }

    // ---------------- FACTORY ----------------

    @Test
    void factory_shouldReturnCorrectAuthenticationMethod() {
        AuthenticationMethodProviderFactory factory =
                new AuthenticationMethodProviderFactory();

        assertTrue(factory.getMethod(MfaMethodType.PASSWORD)
                instanceof PasswordAuthentication);
        assertTrue(factory.getMethod(MfaMethodType.EMAIL_OTP)
                instanceof EmailOtpAuthentication);
        assertTrue(factory.getMethod(MfaMethodType.SMS_OTP)
                instanceof SmsOtpAuthentication);
        assertTrue(factory.getMethod(MfaMethodType.TOTP)
                instanceof TotpAuthentication);
    }
}