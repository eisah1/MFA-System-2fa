/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bradford.mfa.auth;

import com.bradford.mfa.model.User;
import com.bradford.mfa.model.AuthContext;
import com.bradford.mfa.model.AuthResult;

public class PasswordAuthentication implements AuthenticationMethod {

    @Override
    public void begin(User user) {
        // Password authentication doesn't need to send anything, so we can simply log it
        System.out.println("Password Authentication started for: " + user.getUsername());
    }

    @Override
    public AuthResult verify(User user, AuthContext context) {
        // Check if the password matches
        if (user.getPassword().equals(context.getPassword())) {
            return AuthResult.success("Password Verified");
        }
        return AuthResult.failure("Password Incorrect");
    }
}