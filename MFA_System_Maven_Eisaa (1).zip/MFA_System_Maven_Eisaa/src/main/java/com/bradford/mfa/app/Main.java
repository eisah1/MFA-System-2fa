package com.bradford.mfa.app;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) {

        // Load the login page
        UserLoginPage loginPage = new UserLoginPage();
        stage.setScene(loginPage.createScene(stage));

        stage.setTitle("Bradford MFA System");
        stage.setResizable(false);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}