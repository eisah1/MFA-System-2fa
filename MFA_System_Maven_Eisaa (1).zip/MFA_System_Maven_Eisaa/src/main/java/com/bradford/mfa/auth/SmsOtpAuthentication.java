package com.bradford.mfa.auth;

import com.bradford.mfa.model.User;
import com.bradford.mfa.model.AuthContext;
import com.bradford.mfa.model.AuthResult;
import com.twilio.Twilio;
import com.twilio.rest.verify.v2.service.Verification;
import com.twilio.rest.verify.v2.service.VerificationCheck;

public class SmsOtpAuthentication implements AuthenticationMethod {

    // Twilio credentials (use env vars in production)
    public static final String ACCOUNT_SID = "AC8d38477c2984a9f09118f3883ecd888f";
    public static final String AUTH_TOKEN  = "5f844ddc0af5ef8112407358729380b9";
    public static final String VERIFY_SID  = "VA1a56a554bd06cfb8ceeb88148eaf8d0e";

    @Override
    public void begin(User user) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        try {
            Verification.creator(
                    VERIFY_SID,
                    user.getPhoneNumber(),
                    "sms"
            ).create();

            System.out.println("[DEMO] Verification sent to: " + user.getPhoneNumber());

        } catch (Exception e) {
            System.out.println("Error sending SMS: " + e.getMessage());
        }
    }

    @Override
    public AuthResult verify(User user, AuthContext context) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        try {
            VerificationCheck check = VerificationCheck.creator(VERIFY_SID)
                    .setTo(user.getPhoneNumber())
                    .setCode(context.getOtp())
                    .create();

            if ("approved".equalsIgnoreCase(check.getStatus())) {
                return AuthResult.success("OTP Verified");
            } else {
                return AuthResult.failure("OTP incorrect or expired");
            }

        } catch (Exception e) {
            return AuthResult.failure("Error verifying OTP: " + e.getMessage());
        }
    }
}