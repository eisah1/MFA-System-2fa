package com.bradford.mfa.model;

public class AuthContext {

    private final String username;
    private final String password;
    private final String otp;

    public AuthContext(String username, String password, String otp) {
        this.username = username;
        this.password = password;
        this.otp = otp;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getOtp() {
        return otp;
    }
}