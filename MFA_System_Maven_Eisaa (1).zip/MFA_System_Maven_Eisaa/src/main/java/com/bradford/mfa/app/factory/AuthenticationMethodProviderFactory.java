package com.bradford.mfa.app.factory;

import com.bradford.mfa.auth.AuthenticationMethod;
import com.bradford.mfa.auth.PasswordAuthentication;
import com.bradford.mfa.auth.EmailOtpAuthentication;
import com.bradford.mfa.auth.SmsOtpAuthentication;
import com.bradford.mfa.auth.TotpAuthentication;
import com.bradford.mfa.model.MfaMethodType;

import java.util.HashMap;
import java.util.Map;

public class AuthenticationMethodProviderFactory implements AuthenticationMethodProvider {

    private final Map<MfaMethodType, AuthenticationMethod> methods;

    public AuthenticationMethodProviderFactory() {
        this.methods = new HashMap<>();
        buildDefaults();
    }

    private void buildDefaults() {
        methods.put(MfaMethodType.PASSWORD, new PasswordAuthentication());
        methods.put(MfaMethodType.EMAIL_OTP, new EmailOtpAuthentication());
        methods.put(MfaMethodType.SMS_OTP, new SmsOtpAuthentication());
        methods.put(MfaMethodType.TOTP, new TotpAuthentication()); // TOTP support
    }

    @Override
    public AuthenticationMethod getMethod(MfaMethodType type) {
        AuthenticationMethod method = methods.get(type);
        if (method == null) {
            throw new IllegalArgumentException("Unsupported MFA method: " + type);
        }
        return method;
    }

    public void build(MfaMethodType type, AuthenticationMethod method) {
        methods.put(type, method);
    }
}