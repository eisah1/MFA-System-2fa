/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bradford.mfa.auth;

import com.bradford.mfa.model.User;
import com.bradford.mfa.model.AuthContext;
import com.bradford.mfa.model.AuthResult;

public interface AuthenticationMethod {
    // This method starts the authentication process (e.g., sending OTP or prompting for password)
    void begin(User user);
    
    // This method verifies the authentication (e.g., compares password or verifies OTP)
    AuthResult verify(User user, AuthContext context);
}
