package com.bradford.mfa.app.factory;

import com.bradford.mfa.auth.AuthenticationMethod;
import com.bradford.mfa.model.MfaMethodType;

public interface AuthenticationMethodProvider {
    AuthenticationMethod getMethod(MfaMethodType type);
}