package com.bradford.mfa.model;

/**
 * Represents an application user.
 * Stores credentials and MFA-related data.
 */
public class User {

    private String username;
    private String password;
    private String email;
    private String phoneNumber;

    // --- TOTP (Google Authenticator) ---
    private String totpSecret;       // Base32 shared secret
    private boolean totpEnabled;     // Indicates if TOTP is enabled

    /**
     * Creates a new user.
     */
    public User(String username, String password, String email, String phoneNumber) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.totpEnabled = false; // default
    }

    // ===== Getters =====

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getTotpSecret() {
        return totpSecret;
    }

    public boolean isTotpEnabled() {
        return totpEnabled;
    }

    // ===== Setters =====

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Enables TOTP (Google Authenticator).
     * This must be called ONCE during enrolment.
     */
    public void setTotpSecret(String totpSecret) {
        this.totpSecret = totpSecret;
        this.totpEnabled = true;
    }

    /**
     * Disables TOTP and removes the shared secret.
     */
    public void disableTotp() {
        this.totpSecret = null;
        this.totpEnabled = false;
    }
}