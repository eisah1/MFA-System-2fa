package com.bradford.mfa.app;

import com.bradford.mfa.app.factory.AuthenticationMethodProviderFactory;
import com.bradford.mfa.model.AuthContext;
import com.bradford.mfa.model.AuthResult;
import com.bradford.mfa.model.MfaMethodType;
import com.bradford.mfa.model.User;
import com.bradford.mfa.service.AuthenticationService;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;

public class UserLoginPage {

    private final AuthenticationService authService;
    private final User storedUser;

    public UserLoginPage() {
        AuthenticationMethodProviderFactory provider =
                new AuthenticationMethodProviderFactory();
        this.authService = new AuthenticationService(provider);

        this.storedUser = new User(
                "testuser",
                "password",
                "testuser@email.com",
                "+447588412428"
        );
    }

    public Scene createScene(Stage stage) {

        /* ---------- Titles ---------- */
        Label title = new Label("Secure Login");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));

        Label subtitle = new Label("Multi‑Factor Authentication System");
        subtitle.setStyle("-fx-text-fill: #666;");

        /* ---------- Credentials ---------- */
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setPrefHeight(40);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setPrefHeight(40);

        Button loginButton = styledButton("Login", "#0078d4");

        Label status = new Label();

        /* ---------- MFA Selection ---------- */
        ToggleGroup mfaGroup = new ToggleGroup();

        RadioButton smsOption = new RadioButton("SMS OTP");
        smsOption.setToggleGroup(mfaGroup);
        smsOption.setSelected(true);

        RadioButton totpOption = new RadioButton("Google Authenticator");
        totpOption.setToggleGroup(mfaGroup);

        VBox mfaBox = new VBox(8,
                new Label("Choose MFA method"),
                smsOption,
                totpOption
        );
        mfaBox.setVisible(false);
        mfaBox.managedProperty().bind(mfaBox.visibleProperty());

        /* ---------- OTP INPUT (THIS is where user types code) ---------- */
        Label otpLabel = new Label("Enter authentication code");
        TextField otpField = new TextField();
        otpField.setPromptText("6‑digit code");
        otpField.setPrefHeight(40);

        Button verifyButton = styledButton("Verify MFA", "#107c10");

        otpLabel.setVisible(false);
        otpField.setVisible(false);
        verifyButton.setVisible(false);

        otpLabel.managedProperty().bind(otpLabel.visibleProperty());
        otpField.managedProperty().bind(otpField.visibleProperty());
        verifyButton.managedProperty().bind(verifyButton.visibleProperty());

        /* ---------- Password Logic ---------- */
        loginButton.setOnAction(e -> {

            AuthContext context = new AuthContext(
                    usernameField.getText(),
                    passwordField.getText(),
                    ""
            );

            AuthResult result =
                    authService.authenticatePassword(storedUser, context);

            if (result.isSuccess()) {
                status.setStyle("-fx-text-fill: green;");
                status.setText("Password verified. Select MFA option.");
                loginButton.setDisable(true);
                mfaBox.setVisible(true);
            } else {
                status.setStyle("-fx-text-fill: red;");
                status.setText("Invalid username or password.");
            }
        });

        /* ---------- MFA Start ---------- */
        mfaGroup.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {

            MfaMethodType method =
                    (newVal == totpOption)
                            ? MfaMethodType.TOTP
                            : MfaMethodType.SMS_OTP;

            authService.startMfa(storedUser, method);

            status.setStyle("-fx-text-fill: green;");
            status.setText("MFA code sent. Enter the code below.");

            otpLabel.setVisible(true);
            otpField.setVisible(true);
            verifyButton.setVisible(true);
            otpField.requestFocus();
        });

        /* ---------- MFA Verify ---------- */
        verifyButton.setOnAction(e -> {

            Toggle selected = mfaGroup.getSelectedToggle();
            MfaMethodType method =
                    (selected == totpOption)
                            ? MfaMethodType.TOTP
                            : MfaMethodType.SMS_OTP;

            AuthContext context = new AuthContext(
                    usernameField.getText(),
                    passwordField.getText(),
                    otpField.getText()
            );

            AuthResult result =
                    authService.verifyMfa(storedUser, context, method);

            if (result.isSuccess()) {
                status.setStyle("-fx-text-fill: green;");
                status.setText("✅ Login complete. Access granted.");
                verifyButton.setDisable(true);
            } else {
                status.setStyle("-fx-text-fill: red;");
                status.setText("Invalid authentication code.");
            }
        });

        /* ---------- Layout ---------- */
        VBox layout = new VBox(15,
                title,
                subtitle,
                usernameField,
                passwordField,
                loginButton,
                mfaBox,
                otpLabel,
                otpField,
                verifyButton,
                status
        );

        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(30));
        layout.setMaxWidth(400);

        VBox card = new VBox(layout);
        card.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 10;
            -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.15), 10, 0, 0, 0);
        """);

        VBox root = new VBox(card);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #f4f6f8;");
        root.setPadding(new Insets(40));

        return new Scene(root, 520, 560);
    }

    private Button styledButton(String text, String color) {
        Button button = new Button(text);
        button.setPrefHeight(45);
        button.setMaxWidth(Double.MAX_VALUE);
        button.setStyle("""
            -fx-background-color: %s;
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-font-weight: bold;
        """.formatted(color));
        return button;
    }
}