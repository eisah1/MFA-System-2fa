package com.bradford.mfa.auth;

import com.bradford.mfa.model.User;
import com.bradford.mfa.model.AuthContext;
import com.bradford.mfa.model.AuthResult;

import java.security.SecureRandom;

public class EmailOtpAuthentication implements AuthenticationMethod {

    private static final int OTP_LENGTH = 6;
    private static final long OTP_VALIDITY_MS = 60_000; // 60 seconds
    private static final int MAX_ATTEMPTS = 3;

    private final SecureRandom random = new SecureRandom();

    private String currentOtp;
    private long expiresAtMs;
    private boolean used;
    private int attempts;

    @Override
    public void begin(User user) {
        // Generate a fresh OTP each time begin() is called
        this.currentOtp = generateOtp();
        this.expiresAtMs = System.currentTimeMillis() + OTP_VALIDITY_MS;
        this.used = false;
        this.attempts = 0;

        // Simulate sending OTP to user's email
        System.out.println("OTP sent to email: " + user.getEmail());

        // DEMO ONLY: show OTP in console so you can test
        System.out.println("[DEMO] Email OTP for " + user.getUsername() + ": " + currentOtp
                + " (expires in " + (OTP_VALIDITY_MS / 1000) + "s)");
    }

    @Override
    public AuthResult verify(User user, AuthContext context) {

        if (currentOtp == null) {
            return AuthResult.failure("No OTP has been generated. Start OTP authentication first.");
        }

        if (used) {
            return AuthResult.failure("OTP has already been used. Please request a new OTP.");
        }

        if (System.currentTimeMillis() > expiresAtMs) {
            return AuthResult.failure("OTP has expired. Please request a new OTP.");
        }

        if (attempts >= MAX_ATTEMPTS) {
            return AuthResult.failure("Maximum OTP attempts exceeded. Please request a new OTP.");
        }

        String inputOtp = context.getOtp();
        if (inputOtp == null || inputOtp.trim().isEmpty()) {
            return AuthResult.failure("OTP is required.");
        }

        attempts++;

        if (currentOtp.equals(inputOtp.trim())) {
            used = true;          // one-time use
            currentOtp = null;    // clear it out
            return AuthResult.success("OTP Verified");
        }

        int remaining = MAX_ATTEMPTS - attempts;
        return AuthResult.failure("OTP Incorrect. Attempts remaining: " + remaining);
    }

    private String generateOtp() {
        // 6-digit numeric OTP, leading zeros allowed
        StringBuilder sb = new StringBuilder(OTP_LENGTH);
        for (int i = 0; i < OTP_LENGTH; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
}