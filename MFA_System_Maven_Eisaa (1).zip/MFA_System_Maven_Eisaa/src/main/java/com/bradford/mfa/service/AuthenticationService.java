package com.bradford.mfa.service;

import com.bradford.mfa.auth.AuthenticationMethod;
import com.bradford.mfa.app.factory.AuthenticationMethodProvider;
import com.bradford.mfa.model.AuthContext;
import com.bradford.mfa.model.AuthResult;
import com.bradford.mfa.model.MfaMethodType;
import com.bradford.mfa.model.User;

public class AuthenticationService {

    private final AuthenticationMethodProvider provider;

    public AuthenticationService(AuthenticationMethodProvider provider) {
        this.provider = provider;
    }

    /**
     * Step 1: Start MFA challenge (ONLY for methods that send a challenge)
     * - SMS OTP → sends SMS
     * - TOTP → DOES NOTHING (secret already exists)
     */
    public void startMfa(User user, MfaMethodType methodType) {

        AuthenticationMethod method = provider.getMethod(methodType);

        // ✅ Only methods that SEND a code should call begin()
        if (methodType != MfaMethodType.TOTP) {
            method.begin(user);
        }
    }

    /**
     * Step 2: Verify MFA (OTP / TOTP code)
     * - NEVER calls begin()
     */
    public AuthResult verifyMfa(User user, AuthContext context, MfaMethodType methodType) {

        AuthenticationMethod method = provider.getMethod(methodType);
        return method.verify(user, context);
    }

    /**
     * Step 0: Password authentication (single-step)
     */
    public AuthResult authenticatePassword(User user, AuthContext context) {

        AuthenticationMethod method = provider.getMethod(MfaMethodType.PASSWORD);
        method.begin(user);
        return method.verify(user, context);
    }
}