package com.bradford.mfa.auth;

import com.bradford.mfa.model.User;
import com.bradford.mfa.model.AuthContext;
import com.bradford.mfa.model.AuthResult;
import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorConfig;

/**
 * Google Authenticator (TOTP) authentication.
 * Demo-safe implementation with a fixed secret.
 */
public class TotpAuthentication implements AuthenticationMethod {

    // ✅ Fixed demo secret (Base32)
    private static final String FIXED_TOTP_SECRET = "HISYU3DUEHUK3PXY";

    private final GoogleAuthenticator gAuth;

    public TotpAuthentication() {
        GoogleAuthenticatorConfig config =
                new GoogleAuthenticatorConfig.GoogleAuthenticatorConfigBuilder()
                        .setTimeStepSizeInMillis(30_000)
                        .setWindowSize(8)   // tolerant to clock drift
                        .setCodeDigits(6)
                        .build();

        this.gAuth = new GoogleAuthenticator(config);
    }

    /**
     * Enrolment step (called once).
     * Ensures the user has the correct secret.
     */
    @Override
    public void begin(User user) {

        // ✅ Always enforce the demo secret
        if (user.getTotpSecret() == null) {
            user.setTotpSecret(FIXED_TOTP_SECRET);
        }

        System.out.println("======================================");
        System.out.println("GOOGLE AUTHENTICATOR SETUP");
        System.out.println("Account : " + user.getUsername());
        System.out.println("Type    : Time-based");
        System.out.println("SETUP KEY: " + FIXED_TOTP_SECRET);
        System.out.println("======================================");
    }

    /**
     * Verify the TOTP code.
     */
    @Override
    public AuthResult verify(User user, AuthContext context) {

        // ✅ ABSOLUTE GUARANTEE: secret is never null
        if (user.getTotpSecret() == null) {
            user.setTotpSecret(FIXED_TOTP_SECRET);
        }

        if (context.getOtp() == null || context.getOtp().isBlank()) {
            return AuthResult.failure("Authentication code required");
        }

        try {
            int code = Integer.parseInt(context.getOtp());

            boolean valid = gAuth.authorize(
                    user.getTotpSecret(),
                    code
            );

            return valid
                    ? AuthResult.success("TOTP verified")
                    : AuthResult.failure("Invalid or expired authentication code");

        } catch (NumberFormatException e) {
            return AuthResult.failure("Authentication code must be numeric");
        }
    }
}