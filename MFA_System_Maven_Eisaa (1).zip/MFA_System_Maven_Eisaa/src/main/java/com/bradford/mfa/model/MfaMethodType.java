package com.bradford.mfa.model;

public enum MfaMethodType {
    PASSWORD,
    EMAIL_OTP,
    SMS_OTP,
    TOTP
}
